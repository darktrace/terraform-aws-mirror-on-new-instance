// Environment Variables to define for this Lambda
// Session number (SESSION_NUMBER)
// TrafficMirrorFilterId (TRAFFIC_MIRROR_FILTER_ID)
// TrafficMirrorTargetId (TRAFFIC_MIRROR_TARGET_ID)
// VirtualNetworkId (VIRTUAL_NETWORK_ID)
// For tagging restriction - please provide both of the following:
//   TAG_KEY = key of the tag pair to restrict against,
//   TAG_VALUE = value that this must match for lambda to fire.
// When used, mirror sessions will only be applied to instances that
// match the defined key : value pair.

const {
  EC2Client,
  DescribeInstancesCommand,
  CreateTrafficMirrorSessionCommand,
  // eslint-disable-next-line import/no-extraneous-dependencies
} = require('@aws-sdk/client-ec2');

function getTag (tagName, response) {
  let tags;
  try {
    tags = response.Reservations[0].Instances[0].Tags;
  } catch (err) {
    return undefined;
  }

  const foundTag = tags && tags.find((t) => t.Key === tagName);
  return foundTag && foundTag.Value;
}

function getInterfaceId (response) {
  let interfaceId;
  try {
    interfaceId = response.Reservations[0].Instances[0].NetworkInterfaces[0].NetworkInterfaceId;
  } catch (err) {
    return undefined;
  }
  return interfaceId;
}

exports.handler = async (event) => {
  const client = new EC2Client({ apiVersion: '2016-11-15' });

  if (
    !process.env.SESSION_NUMBER
    || !process.env.TRAFFIC_MIRROR_FILTER_ID
    || !process.env.TRAFFIC_MIRROR_TARGET_ID
    || !process.env.VIRTUAL_NETWORK_ID
  ) {
    throw new Error('one of the required environment variables is not defined - set this for your lambda task, please refer to documentation. Exiting.');
  }

  if (
    (process.env.TAG_KEY || process.env.TAG_VALUE)
    && !(process.env.TAG_KEY && process.env.TAG_VALUE)
  ) {
    throw new Error('When TAG_KEY or TAG_NAME is used, both must be provided');
  }

  const instanceId = event?.detail?.['instance-id'];
  if (typeof instanceId !== 'string') {
    throw new Error('expected a string for instance-id');
  }
  const response = await client.send(new DescribeInstancesCommand({
    InstanceIds: [
      instanceId
    ]
  }));

  const name = getTag('Name', response);
  if (!name) {
    throw new Error('Name not set, cannot continue');
  }
  if (process.env.TAG_KEY && process.env.TAG_VALUE) {
    const tagkey = getTag(process.env.TAG_KEY, response);
    if (!tagkey) {
      return `Not configuring mirror session for instance ${instanceId} ${name} as no matching tag key was found for this instance.`;
    }
    if (tagkey !== process.env.TAG_VALUE) {
      return `Not configuring mirror session for instance ${instanceId} ${name} as tag value does not correspond to required value for this instance`;
    }
  }

  const interfaceId = getInterfaceId(response);
  if (!interfaceId) {
    throw new Error('No interface found for this instance, cannot continue');
  }

  await client.send(new CreateTrafficMirrorSessionCommand({
    NetworkInterfaceId: interfaceId,
    SessionNumber: process.env.SESSION_NUMBER,
    TrafficMirrorFilterId: process.env.TRAFFIC_MIRROR_FILTER_ID,
    TrafficMirrorTargetId: process.env.TRAFFIC_MIRROR_TARGET_ID,
    Description: `mirror session for ${instanceId}`,
    TagSpecifications: [
      {
        ResourceType: 'traffic-mirror-session',
        Tags: [
          {
            Key: 'Name',
            Value: instanceId
          },
          {
            Key: 'InstanceName',
            Value: name
          }
        ]
      },
    ],
    VirtualNetworkId: process.env.VIRTUAL_NETWORK_ID,
  }));

  return `Mirror Session created for instance ${instanceId}, interface id ${interfaceId}, instance name ${name}`;
};
